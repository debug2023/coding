<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Login</title>
<style type="text/css">
<!--
.style1 {
	font-size: x-large;
	font-weight: bold;
}
-->
</style>
</head>

<body>

 <form action="" method="post" >
      
       <table width="790" bgcolor="#FFFFFF" border="2" border="5" bordercolor="#000000" align="center">
          <tr bordercolor="#FFFF00" bgcolor="#FFFFFF">
            <td width="390"><p align="center"><img src="image_company.png" width="304" height="114" /></p>
              
              <table width="350" border="0" align="center">
                <tr>
                  <td width="149"><div align="left">USERNAME</div></td>
                  <td width="10">:</td>
                  <td width="177"><input type="text" name="" id="" /></td>
                </tr>
                
                <tr>
                  <td>PASSWORD</td>
                  <td>:</td>
                  <td><input type="password" name="" id="" /></td>
                </tr>
              </table>
              
    		  <table width="250" border="0" align="center">
                <tr>
                  <td width="127">&nbsp;</td>
                  <td width="113"><input type="submit" name="login" id="login" value="LOGIN" /></td>
                </tr>
              </table>
              
 </form>
	
</body>
</html>
