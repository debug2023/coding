<?php
include 'config.php';
//code
?>

<table align="center">
<p align="center">Senarai Nama Kursus</p>
		<td align="center" bgcolor="green">Kod Kursus</td>
		<td align="center" bgcolor="green">Nama Kursus</td>
		<td align="center" bgcolor="green">Trainer</td>
		<td align="center" bgcolor="green">Tarikh kursus</td>
			<td align="center" bgcolor="green">Status</td>
			<td align="center" bgcolor="green">Kemaskini</td>
						<td align="center" bgcolor="green">Hapus</td>

<?php
//code

echo "<td>","<a href=\"formkemaskini.php?kod_kursus=$kod_kursus\">Kemaskini</a>";
echo "<td>","<a href=\"pros_delete.php?kod_kursus=$kod_kursus\">Hapus</a>";
echo"</tr>";
}
echo "</table>";
?>
<br><br><h3><center><a href="form.php">Daftar Kursus</a></center></h3>