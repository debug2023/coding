<?php
include 'config.php';
//code
?>