<!DOCTYPE html>
<html>
<head>
	<title>Training Center</title>
</head>
<body>
<form action="pros_insert.php" method="POST">
	<center>
	<br>Kod Kursus</br>
		<br><input type="text" name="kod_kursus"></br>
		<br>Nama Kursus</br>
	<br><input type="text" name="nama_kursus"></br>
	<br>Training</br>
	<br>	<input type="text" name="trainer"></br>
	<br>Tarikh Kursus</br>
			<br><input type="date" name="tarikh_kursus"></br>
			<br>Status</br>
			<br>	<input type="text" name="status"></br>
				<br><input type="submit" name="submit" value="submit">
	</center>




</form>
</body>
</html>