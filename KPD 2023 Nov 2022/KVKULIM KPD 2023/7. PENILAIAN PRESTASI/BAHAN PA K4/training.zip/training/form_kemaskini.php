<!DOCTYPE html>
<html>
<head>
	<title>Training Center</title>
</head>
<body>
<?php

<?



<form action="" method="POST">
	<center>
	<br>Kod Kursus</br>
		<br><input type="text" name="kod_kursus" value=""></br>
		<br>Nama Kursus</br>
	<br><input type="text" name="nama_kursus" value=""></br>
	<br>Training</br>
	<br>	<input type="text" name="trainer" value=""></br>
	<br>Tarikh Kursus</br>
			<br><input type="date" name="tarikh_kursus" value=""></br>
			<br>Status</br>
			<br>	<input type="text" name="status"></br>
				<br><input type="submit" name="submit" value="submit">
	</center>




</form>
</body>
</html>