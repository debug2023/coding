<?php
include('config.php');
//lengkapkan kod selepas baris ini

//kod tamat
?>
<head>
	<title>Senarai Pelajar</title>
	<style>
	 #header {width:100%; height:60px; border:1px solid #333; background-color: beige; 
	 	text-align: center;}
	</style>
</head>
<body>
	<div id="header">
		<h1> KELAB CATUR KV SIMFONI </h1>
<hr>
<table align="center">
	<center><h2>KELAB CATUR SIMFONI</h2><center>
<p align="center">Senarai Nama Pelajar</p>
		<td align="center" bgcolor="grey">Id Pelajar</td>
		<td align="center" bgcolor="grey">Nama Pelajar</td>
		<td align="center" bgcolor="grey">No Kad Pengenalan</td>
		
		<td align="center" bgcolor="grey">Tindakan</td>

<?php	
//Lengkapkan kod selepas baris ini//	













//lengkapkan sehingga baris ini//
?>
<hr>
<h3><center><a href="add.php">Tambah Rekod</a></center></h3>
</table>
</body>
</head>