<?php
//Lengkapkan kod selepas baris ini//
include('config.php'); 

	


	  

	//Lengkap kod Tamat	

	echo "<script>alert('Berjaya Padam maklumat $nama_pelajar');
	". "window.location='senarai_pelajar.php'</script>";

	
?> 