<?php
<!--membuat sambungan ke db-->
//LENGKAPKAN KOD SELEPAS BARIS INI

<head>
	<title>Rekod Vaksinasi Pelajar</title>
	<style>
	 #header {width:100%; height:60px; border:1px solid #333; background-color:blanchedalmond;  text-align: center;}
	</style>
</head>
<body>
	
<hr>
<table align="center">
	<center><h2>REKOD VAKSINASI PELAJAR KV SEPANG TAHUN 2022</h2><center>
<p align="center">Senarai Rekod Vaksinasi Pelajar</p>
		<td align="center" bgcolor="lightblue">No Kad Pengenalan</td>
		<td align="center" bgcolor="lightblue">Nama Pelajar</td>
		<td align="center" bgcolor="lightblue">Kelas</td>
		<td align="center" bgcolor="lightblue">Jenis Vaksin</td>
		<td align="center" bgcolor="lightblue">Tarikh_Vaksin</td>
		<td align="center" bgcolor="lightblue">Tindakan</td>

<?php	
//Lengkapkan kod selepas baris ini//	


//LENGKAPKAN SEHINGGA BARIS INI//
?>
<hr>
<h3><center><a href="add.php"> ++ Tambah Rekod</a></center></h3>
</table>
</body>
</head>