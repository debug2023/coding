<html>
	<head><title>Laman Web STTS</title>
	<link rel="stylesheet" type = "text/css" href="style.css">
	</head>
		<body>
            
          
<div id="container">

        <div id="banner" align="center">
        <img src="img/logo3.png" width="208" height="242"  align="bottom">
        </div>
        
        <div id = "header">

                <h1>SEKOLAH TEKNOLOGI TINGGI SEKALI</h1>
        </div>

        <div id="content">
            
          <div id="nav">
                    <ul>
                    <li align="center"><h3>MENU NAVIGASI</h3></li>
                    <li align="center"><h3>______________</h3></li>
                    <li><a href="index.php">UTAMA</a></li>
                    <li><a href="#">PENGUMUMAN</a></li>
                    <li><a href="login.php" target="_blank">LOG MASUK</a></li>

                    </ul>
                    </div>
            
                    <div id="main">
                        
                        <p>Selamat Sejahtera, <br>
                           Diminta semua pensyarah dan pelajar untuk log masuk bagi menggunakan sistem-sistem yang telah disediakan.
                        Fungsi Log Masuk boleh di pilih di bahagian Menu Navigasi.</p>
                      <p>Terima Kasih.</p>
                        <center><img src="img/hi.png" width="215" height="215"></img>
    

                    </div>
        </div>

                <div id="footer">Copyright &copy; 2019
                </div>

            </div>

                </body>
        </html>