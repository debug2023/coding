<?php 

include 'config.php';

session_destroy("maklumatbot.php");
header("Location: index.php");
 ?>