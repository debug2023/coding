<?php //tambah permulaan php
  $connect = mysqli_connect('localhost', 'root', '', '') or die('Failed to connect to db....') ; //tambah nama pangkalan data
?>